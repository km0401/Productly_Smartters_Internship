import Image from "next/image";
import Link from 'next/link';
import LogoImage from "../../public/img/logo.svg";
import styles from "../components/header.module.css";

const header = () => {
  return (
    <div className={styles.headerContainer}>
      <div className={styles.logoContainer}>
        <Image src={LogoImage} alt="logo-image" className={styles.logoImage}/>
      </div>
      <nav className={styles.navbarContainer}>
        <ul className={styles.navbarLinkContainer}>
        <span>
            <Link href="#Categories"><li id={styles.navbarLinks}>Product</li></Link>
            <Link href="#Customers"><li id={styles.navbarLinks}>Customers</li></Link>
            <Link href="#Pricing"><li id={styles.navbarLinks}>Pricing</li></Link>
            <Link href="#Resources"><li id={styles.navbarLinks}>Resources</li></Link>
              <Link href="/signin"><button className={styles.navbarSignInButton}>Sign In</button></Link>
              <Link href="/signup"><button className={styles.navbarSignUpButton}>Sign Up</button></Link>
          </span>
        </ul>
      </nav>
    </div>
  );
};

export default header;
