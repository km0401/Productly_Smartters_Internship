import Image from "next/image";
import validationImage from "../../public/img/validation/validation.png";
import styles from "../page-components/customers.module.css";

const customers = () => {
  return (
    <div className={styles.customersContainer}>
      <div className={styles.columnContainer}>
        <h5 className={styles.textHeadingCustomers}>Effortless Validation for</h5>
        <h2 className={styles.boldTextTitleCustomers}>Design Professionals</h2>
        <p>
          The Myspace page defines the individual,his or her characteristics, traits, personal choices and the overall personality of the person.
        </p>
        <h4 className={styles.textHeadingCustomers}>Accessory makers</h4>
        <p>
          While most people enjoy casino gambling, sports betting lottery and bingo playing for the fun
        </p>
        <h4 className={styles.textHeadingCustomers}>Alterationists</h4>
        <p>
          If you are looking for a new way to promote your business that won't cost you money,
        </p>
        <h4 className={styles.textHeadingCustomers}>Custom Design designers</h4>
        <p>
          If you are looking for a new way to promote your business that won't cost you more money,
        </p>
      </div>
      <div className={styles.columnContainer}>
        <Image src={validationImage} alt="" width="480" height="550"/>
      </div>
    </div>
  );
};

export default customers;
